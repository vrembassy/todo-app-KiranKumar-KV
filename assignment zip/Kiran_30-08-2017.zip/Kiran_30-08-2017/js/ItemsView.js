window.Todo=window.Todo || {}


Todo.ItemsView=(function(){
				return{
				init: function() {
					//cache DOM node $ul
					$ul=document.getElementById("itemContainer");
				},
				display: function(collection) {
					alert("hi");
					collection.forEach(function(model){
						//document.getElementById().appendChild //dont do this 
						$ul.appendChild(ItemView.display(model)) //do this
					});
				},
				add: function(model){
					$ul.appendChild(ItemView.display(model));
				},
				remove: function() {
					todo.ItemView.remove();
				}
				
};

})();