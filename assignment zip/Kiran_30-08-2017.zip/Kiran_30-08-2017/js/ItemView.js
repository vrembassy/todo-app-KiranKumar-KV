window.Todo=window.Todo || {}
//window.Todo.ItemView=ItemVIew;

Todo.ItemView=(function(){
			return{
				init: function(){
					//cache DOM nodes 
						
					//register event handlers
					
				},
				display: function(){
					//createDOMElement('li');
					//return DOMNode
					alert("hi");
				},
				remove: function(){
					
				},	
				
};
})();