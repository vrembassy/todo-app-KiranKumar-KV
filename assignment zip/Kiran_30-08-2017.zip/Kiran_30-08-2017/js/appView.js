window.Todo=window.Todo || {}


	
window.Todo.appView = (function(){
	return{
				init: function(){
					
				},
				display: function() {
					alert("hello");
					Todo.ItemView.display();
				},
				remove: function() {
					Todo.ItemsView.remove();
				},
				addToItem: function(itemModel) {
					Todo.ItemsView.add(itemModel);
				}

};	
})();

	Todo.appView.display();	