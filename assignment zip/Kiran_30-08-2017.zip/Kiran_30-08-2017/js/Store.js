window.Todo=window.Todo || {}
Todo.Store

Store = {
		load: function(){
					
		},
		save: function(){
					console.log("New todo item stored.  id : "+insertedItems.id+", name : "+insertedItems.name+", status : "+insertedItems.state);
	
	                // storing the todo items using objects inside an object
	
					//getting the id of the inserted item to use as index
					idOfTheItem = insertedItems.id;
					//storing the javascript object inside another object
					//public method invocation
					todo.appView.toDOItems[idOfTheItem] = insertedItems;
					console.log("Stored items summary :");
					console.log(todo.appView.toDoItems);
				
		}
};